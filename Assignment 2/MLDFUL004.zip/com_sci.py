#Program to output text using ASCII Art
#Fulufhelo Mulaudzi
#28 February 2024

print("  ____ ____ ___ ____  _____ _   _ _   _ _ ")
print(" / ___/ ___|_ _/ ___||  ___| | | | \\ | | |")
print("| |   \\___ \\| |\\___ \\| |_  | | | |  \\| | |")
print("| |___ ___) | | ___) |  _| | |_| | |\\  |_|")
print(" \\____|____/___|____/|_|    \\___/|_| \\_(_)")