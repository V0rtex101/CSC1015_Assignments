#Program to output energy value using m and c
#Fulufhelo Mulaudzi
#22 February 2024

#Get input from the user
m = int(input("Enter the value of m:\n"))
c = int(input("Enter the value of c:\n"))

#calculate energy using the formula
energy = m * c**2

#Output the energy value
print(f"The value of energy, E, is: {energy}")
