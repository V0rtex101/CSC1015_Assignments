#testpalindrome.py
"""
>>> import palindrome
>>> palindrome.is_palindrome('')
True
>>> palindrome.is_palindrome('f')
True
>>> palindrome.is_palindrome('52645')
False
>>> palindrome.is_palindrome('step on no pets')
True
>>> palindrome.is_palindrome('Ava')
False

"""
import doctest
doctest.testmod(verbose=True)